select brand, 
	kv1['华北'] hb_price, kv2['华北'] hb_qty, 
	kv1['华东'] hd_price, kv2['华东'] hd_qty, 
	kv1['东北'] db_price, kv2['东北'] db_qty, 
	kv1['华南'] hn_price, kv2['华南'] hn_qty, 
	kv1['西南'] sn_price, kv2['西南'] xn_qty,
	kv1['西北'] xb_price, kv2['西北'] xb_qty
 from (
	select brand, str_to_map(concat_ws(',', collect_set(concat(area_name, '-', total_price_actual))),',','-') kv1,
	 str_to_map(concat_ws(',', collect_set(concat(area_name, '-', qty))),',','-') kv2
  	from (
		select brand, area_name, sum(total_price_actual) total_price_actual, sum(qty) qty
		from hive_temp_vipvop.vop_xstore_retail 
		group by brand, area_name
	) tmp
   group by brand
 ) t



select cost_area_code,
       kv['202201'] 202201,
       kv['202202'] 202202,
       kv['202203'] 202203,
       kv['202204'] 202204,
       kv['202205'] 202205,
       kv['202206'] 202206,
       kv['202207'] 202207,
       kv['202208'] 202208,
       kv['202209'] 202209,
       kv['202210'] 202210,
       kv['202211'] 202211,
       kv['202212'] 202212
from 
(select cost_area_code, str_to_map(concat_ws(',', collect_set(concat(hq_month_code, '-', total_reso_amt))),',','-') kv
  	from (
		select t.cost_area_code,t.hq_month_code,sum(to_reso_amt) total_reso_amt from dm_fin_itp.itp_fc_bsl_tar_cost_output_f t
        where 
        t.cost_area_code = '010Y'
        and t.judge_flag = '本BG他区'
        group by t.cost_area_code,t.hq_month_code
	) tmp
   group by cost_area_code ) t ;


select cost_area_code, str_to_map(concat_ws(',', collect_set(concat(hq_month_code, '-', total_reso_amt))),',','-') kv
  	from (
		select t.cost_area_code,t.hq_month_code,sum(to_reso_amt) total_reso_amt from dm_fin_itp.itp_fc_bsl_tar_cost_output_f t
        where 
        t.cost_area_code = '010Y'
        and t.judge_flag = '本BG他区'
        group by t.cost_area_code,t.hq_month_code
	) tmp
   group by cost_area_code ;

   