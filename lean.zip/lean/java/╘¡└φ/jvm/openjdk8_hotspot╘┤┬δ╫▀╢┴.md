###类加载


###monitorenter-exit走读


###垃圾回收